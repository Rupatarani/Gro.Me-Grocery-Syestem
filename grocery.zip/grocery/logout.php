<?php

header("location:index.php?logout=true");

?>