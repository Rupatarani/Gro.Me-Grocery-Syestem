<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="css/ragister.css" rel="stylesheet">
<script>
$(function() {

    $('#login-form-link').click(function(e) {
		$("#login-form").delay(100).fadeIn(100);
 		$("#register-form").fadeOut(100);
		$('#register-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});
	$('#register-form-link').click(function(e) {
		$("#register-form").delay(100).fadeIn(100);
 		$("#login-form").fadeOut(100);
		$('#login-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});

});

</script>

<?php
require_once"dbconfig.php";
?>
<div class="container">
    	<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<div class="panel panel-login">
					<div class="panel-heading">
						<div class="row">
							<div class="col-xs-6">
								<a href="#" class="active" id="login-form-link">Admin / Rider Login</a>
							</div>
						</div>
						<hr>
					</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-lg-12">
								<form id="login-form"  method="post" role="form" style="display: block;">
									<div class="form-group">
										<input type="text" required name="email" id="email" tabindex="1" class="form-control" placeholder="Username / Email" value="">
									</div>
									<div class="form-group">
										<input type="password" required name="password" id="password" tabindex="2" class="form-control" placeholder="Password">
									</div>
									
									<div class="form-group">
										<div class="row">
											<div class="col-sm-6 col-sm-offset-3">
												<input type="submit" name="login" id="login-submit" tabindex="4" class="form-control btn btn-login" value="Log In">
											</div>
										</div>
									</div>
									
								</form>


								
<?php	

	if(isset($_REQUEST['login'])) {

		extract($_REQUEST);
		
		$query="select * from admin where email='$email' and password='$password'";
		$login_data = select($query);

		$n = mysqli_num_rows($login_data);
		
		if ($n==1) {
			while($data=mysqli_fetch_array($login_data)) {

				extract($data);
						
				$_SESSION['admin_id'] = $id;
				$_SESSION['adminusername']=$email;
				$_SESSION['adminlogin']="yes";
			
				header("location:adminhome.php");

			}

		}
		else {
			echo"username or password is incorrect";
		}
	
	}
	?>
							</div>
						</div>
					</div>
				</div>

			<br>
			Click <a href="index.php">here</a> to go back to the Grocery Store website.		

			</div>
		</div>


	</div>

