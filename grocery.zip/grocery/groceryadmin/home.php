<?php

	require_once '_config.php';

	function main() {

		?>

			<div class="row">
				<div class="col">

					<h1>Home</h1>

					<b>Select an option from the menu provided below.</b><br>
					<br>

					<a href="inventory.php"><img src="images/inventory.png"> <b>Inventory</b></a><br><br>

					<a href="orders.php"><img src="images/cargo.png"> <b>Orders / Deliveries</b></a><br><br>

					<a href="customers.php"><img src="images/rating.png"> <b>Customers</a><br><br>

					<a href="users.php"><img src="images/programmer.png"> <b>Users</a><br><br>

				</div>
			</div>

		<?php 

	}

	include '_template.php';

?>