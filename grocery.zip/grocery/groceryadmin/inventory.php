<?php

	require_once '_config.php';

	function main() {

		?>

			<div class="row">
				<div class="col">

					<h1>Inventory</h1>
					<a href="main.php" class="btn btn-primary btn-sm">Back to Home</a>

				</div>
			</div>

			<div class="row mt-4">
				<div class="col">

					





				</div>
			</div>


		<?php

	}

	include '_template.php';


?>