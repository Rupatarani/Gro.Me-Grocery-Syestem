
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Grocery Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="bootstrap_icons.css">
    <link rel="stylesheet" href="okaida.css">
    <link rel="stylesheet" href="custom.css">

    <script src="bootstrap.js"></script>
    <script src="prism.js" data-manual></script>
    <script src="custom.js"></script>

    <script src="https://cdn.datatables.net/2.2.1/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/2.2.1/js/dataTables.bootstrap5.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.2.1/css/dataTables.bootstrap5.css">      

    <!-- Global Site Tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-KGDJBEFF3W"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-KGDJBEFF3W');
    </script>

    <style>

      a {

        text-decoration: none;

      }

    </style>

  </head>
  <body>

    <?php 

      $page = 'index.php';
      if ($_SESSION[USERNAME] != '') {
        $page = 'home.php';
      }

    ?>
    <div class="navbar navbar-expand-lg fixed-top bg-primary" data-bs-theme="dark">
      <div class="container">
        <a href="<?php echo $home; ?>" class="navbar-brand" style="margin-bottom: 4px;"><b>Grocery</b> <small style="font-size: smaller;"><b>ADMIN</b></small></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav">
            <!--
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="https://blog.bootswatch.com/">Blog</a>
            </li>
            <li class="nav-item dropdown" data-bs-theme="light">
              <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" id="download">Minty</a>
              <div class="dropdown-menu" aria-labelledby="download">
                <a class="dropdown-item" rel="noopener" target="_blank" href="https://jsfiddle.net/bootswatch/7nb04mas/">Open in JSFiddle</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="../5/minty/bootstrap.css" download>bootstrap.css</a>
                <a class="dropdown-item" href="../5/minty/bootstrap.min.css" download>bootstrap.min.css</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="../5/minty/bootstrap.rtl.css" download>bootstrap.rtl.css</a>
                <a class="dropdown-item" href="../5/minty/bootstrap.rtl.min.css" download>bootstrap.rtl.min.css</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="../5/minty/_variables.scss" download>_variables.scss</a>
                <a class="dropdown-item" href="../5/minty/_bootswatch.scss" download>_bootswatch.scss</a>
              </div>
            </li>
            -->
          </ul>
          <?php 

            if ($_SESSION[USERNAME] != '') {

              ?>
                <ul class="navbar-nav ms-md-auto">

                  <li class="nav-item">
                    <a class="nav-link" href="#" style="color: #fff;"></a>
                  </li>

                  <li class="nav-item dropdown" data-bs-theme="light">
                    <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" id="download"><i class="bi bi-user"></i>User: <b><?php echo $_SESSION[USERNAME]; ?></b></a>
                    <div class="dropdown-menu" aria-labelledby="download">

                      <!--
                      <a class="dropdown-item" rel="noopener" target="_blank" href="https://jsfiddle.net/bootswatch/7nb04mas/">Open in JSFiddle</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="../5/minty/bootstrap.css" download>bootstrap.css</a>
                      <a class="dropdown-item" href="../5/minty/bootstrap.min.css" download>bootstrap.min.css</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="../5/minty/bootstrap.rtl.css" download>bootstrap.rtl.css</a>
                      <a class="dropdown-item" href="../5/minty/bootstrap.rtl.min.css" download>bootstrap.rtl.min.css</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="../5/minty/_variables.scss" download>_variables.scss</a>
                      <a class="dropdown-item" href="../5/minty/_bootswatch.scss" download>_bootswatch.scss</a>

                      -->

                      <a class="dropdown-item" href="index.php" onclick="return confirm('Confirm logout?');">Log out</a>

                    </div>
                  </li>

                </ul>

              <?php 
            }

          ?>
        </div>
      </div>
    </div>

    <div class="container">

      <?php

        if (function_exists('main')) main();

      ?>

    </div>

  </body>
</html>
