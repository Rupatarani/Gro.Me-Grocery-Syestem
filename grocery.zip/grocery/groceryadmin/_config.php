<?php

	session_start();
	date_default_timezone_set('Asia/Kuala_Lumpur');

	$dbserver 		= 'localhost';
	$dbuser 		= 'root';
	$dbpass  		= '';
	$dbname  		= 'online_grocery';

	define('USERNAME', 'admin_username');
	define('USERROLE', 'admin_userrole');
	define('RESULT', 'admin_result');

	if (!isset($_SESSION[USERNAME])) $_SESSION[USERNAME] = '';
	if (!isset($_SESSION[USERROLE])) $_SESSION[USERROLE] = '';
	if (!isset($_SESSION[RESULT])) $_SESSION[RESULT] = '';

	$db = mysqli_connect(
		$dbserver, 
		$dbuser, 
		$dbpass, 
		$dbname) 
	or die("Database connection error");

?>