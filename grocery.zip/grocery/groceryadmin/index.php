<?php

	require_once '_config.php';

	function main() {

		global $db;

		$_SESSION[USERNAME] = '';
		$_SESSION[USERROLE] = '';
		
		?>

			<div class="row">
				<div class="col">
					<h1><b>Grocery</b> <small style="font-size: smaller; color: gray;">ADMIN</small></h1>
				</div>
			</div>

			<div class="row mt-4">
				<div class="col">
					<h3>Login</h3>
					Enter your username and password to log in to this system.
					<br><br>

					<div class="card card-primary" style="width: 360px;">
						<div class="card-header bg-primary text-light">
							<b>Login</b>
						</div>
						<div class="card-body">

							<form method="post" action="action.php">
								
								<input type="hidden" name="action" value="login">

								<b>Username</b>
								<input type="text" class="form-control" name="username" required>
								<br>
								<b>Password</b>
								<input type="password" class="form-control" name="password" required>
								<br>
								<button type="submit" class="btn btn-primary">Log In</button>
							
							</form>


						</div>
					</div>

				</div>
			</div>


		<?php


	}

	include '_template.php';

?>