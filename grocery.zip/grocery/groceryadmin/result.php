<?php

	require_once '_config.php';

	function main() {

		if ($_SESSION[RESULT] == '') {

			$page = 'index.php';

			if ($_SESSION[USERNAME] != '') {

				$page = 'home.php';

			}

			?>

				<div class="row">
					<div class="col">

						<meta http-equiv="refresh" content="0;url=<?php echo $page; ?>">

					</div>
				</div>

			<?php 
		}

		else {

			?>

				<div class="row">
					<div class="col">

						<?php 

							echo $_SESSION[RESULT]; 
							$_SESSION[RESULT] = '';

						?>

					</div>
				</div>

			<?php

		}

	}

	include '_template.php';

?>