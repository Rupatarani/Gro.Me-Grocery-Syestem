<?php 

	require_once '_config.php';

	// actions here 
	// all POST requests are handled here 

	function debug() {

		echo '<pre>';
		print_r($_REQUEST);
		echo '</pre>';

	}

	$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';

	if ($action == 'login') {

		$name = filter_var($_REQUEST['username'], FILTER_SANITIZE_STRING);
		$pass = filter_var($_REQUEST['password'], FILTER_SANITIZE_STRING);

		$sql = 'select * from admin where name = "' . $name . '" and password = "' . $pass . '" ';
		$qry = $db->query($sql);
		if ($qry->num_rows > 0) {

			while ($fetch = $qry->fetch_assoc()) {

				$_SESSION[USERNAME] = $fetch['name'];
				$_SESSION[USERROLE] = $fetch['role'];

				$_SESSION[RESULT] = '
				
					<h3>User login successful.</h3>
					<br>

					<a href="home.php" class="btn btn-primary">OK</a>
					
					<meta http–equiv="refresh" content="1;url=home.php"

				';
			}
		}

		else {

			$_SESSION[USERNAME] = '';
			$_SESSION[USERROLE] = '';

			$_SESSION[RESULT] = '

				<h3>Login failed.</h3>
				<br>
				Either username or password is incorrect.<br>
				Please try again.<br>
				<br>
				<a href="index.php" class="btn btn-primary">Back to login</a>

			';
		}

	}

	function main() {

		?>

			<meta http-equiv="refresh" content="0;url=result.php">

		<?php 

	}

	include '_template.php';


?>