                                   <a class="nav-link" style="font-weight: normal;" href="#">Welcome, <b><?php echo strtoupper($_SESSION['name']); ?></b></a>

                                    <a class="nav-link" href="askme.php">Ask Me Anything</a>

    								<a class="nav-link" href="mycart.php">My Cart</a>

                                    <a class="nav-link" href="myorders.php">My Orders</a>

    								<a class="nav-link" href="category.php">Category</a>
                              
                                    <a class="nav-link" href="logout.php" onclick="return confirm('Confirm logout?');">Logout</a>
