<?php
require_once"dbconfig.php";

if (isset($_GET['logout'])) {
    $_SESSION['userid'] = '';
    $_SESSION['name'] = '';
    $_SESSION['login'] = '';
}

function getChatGPTResponse($prompt) {
    $apiKey = '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';

    $url = 'https://api.openai.com/v1/chat/completions';

    $data = [
        'model' => 'gpt-4o-mini', // or 'gpt-4' if you have access
        'messages' => [['role' => 'system', 'content' => 'You are a helpful assistant.'], ['role' => 'user', 'content' => $prompt]],
        'max_tokens' => 500, // Limit the response length
    ];

    $headers = [
        "Authorization: Bearer $apiKey",
        'Content-Type: application/json',
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <title>Index</title>

     <link href="style.css" rel="stylesheet">

    <link href="css/responsive/responsive.css" rel="stylesheet">
<script src="jquery.min.js"></script>
	<script>  
 $(document).ready(function(){  
      $('#country').keyup(function(){  
           var query = $(this).val();
aler(query);		   
           if(query != '')  
           {  
                $.ajax({  
                     url:"searchinput.php",  
                     method:"POST",  
                     data:{query:query},  
                     success:function(data)  
                     {  
                          $('#countryList').fadeIn();  
                          $('#countryList').html(data);  
                          
                     }  
                });  
           }  
      });  
      $(document).on('click', 'li', function(){  
           $('#country').val($(this).text());  
           $('#countryList').fadeOut();  
      }); 

$('.navbar-light .dmenu').hover(function () {
        $(this).find('.sm-menu').first().stop(true, true).slideDown(150);
    }, function () {
        $(this).find('.sm-menu').first().stop(true, true).slideUp(105)
    });	  
 });  
 </script>  
</head>

<body>
    <div id="preloader">
        <div class="dorne-load"></div>
    </div>

   <header class="header_area" id="header">
        <div class="container-fluid h-100">
            <div class="row h-100">
                <div class="col-12 h-100">
                    <nav class="h-100 navbar navbar-expand-lg">
                        <a class="navbar-brand" href="index.php">GROCERY ONLINE SHOPPING</a>
                       
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#dorneNav" aria-controls="dorneNav" aria-expanded="false" aria-label="Toggle navigation"><span class="fa fa-bars"></span></button>
                        <!-- Nav -->
                        <div class="collapse navbar-collapse" id="dorneNav">
                            <ul class="navbar-nav mr-auto" id="dorneMenu">
                                <li class="nav-item active">
                                    <a class="nav-link" href="index.php"><span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item dropdown">
                                    <
                                </li>
                                
                            </ul>
                             <div class="dorne-signin-btn">
							   <?php
							   if(isset($_SESSION['login']) && $_SESSION['login'] != '')
							   {

                                    include('usermenu.php');

								   ?>

                                   <!--
                                   <a class="nav-link" style="font-weight: normal;" href="myprofile.php">Welcome, <b><?php echo strtoupper($_SESSION['name']); ?></b></a>

    								<a class="nav-link" href="mycart.php">My Cart</a>

                                    <a class="nav-link" href="myorders.php">My Orders</a>

    								<a class="nav-link" href="category.php">Category</a>
                              
                                    <a class="nav-link" href="logout.php">Logout</a>
                                    
                                    -->
                               
								   
								   <?php
							   }
								   else
								   {
									   ?>
									   <a href="ragister.php">Sign in  or Register</a>
								<a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
								<a class="nav-link" href="category.php">Category</a>
                              

                                <a class="nav-link" href="admin/">Admin Login</a>
								   <?php
								   }
							   
							   ?>
                               

                            </div>
                           
                            
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
     <section class="dorne-welcome-area bg-img bg-overlay" style="background-image: url(img/bg-img/hero-1.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center justify-content-center">
                <div class="col-12 col-md-6"></br></br>
                    <div class="hero-content"></br></br></br></br></br>
                        
                        <h1 style="color:white;font-weight:bold;  text-shadow: 2px 2px 14px #7546E4;">ASK ME ANYTHING</h1>

                        <form method="post">

                            <div class="form-group row col-12">
                                <textarea rows="3" name="askme" class="form-control" required></textarea>
                            </div>

                            <div class="form-group row col-12">

                                <button type="submit" class="btn btn-primary">Submit</button>

                            </div>

                        </form>
                        <br><br>
                        
                    </div>
                          
                </div>
            </div>
        </div>

    </section>
    

    <div class="container-fluid">
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">

                <br><br>

                <div style="width: 100%; height: 500px; overflow-y: scroll;">
                    <b>Question:</b><br>
                    <?php 

                        if (isset($_POST['askme']) && $_POST['askme'] != '') {

                            echo $_POST['askme'];
                        }

                    ?>
                    <br><br>

                    <b>Answer:</b><br>

                    <?php 

                        $prompt = $_POST['askme'];

                        $response = getChatGPTResponse($prompt);

                        //echo '<pre>';
                        //print_r($response);
                        //echo '</pre>';

                        $recommendations = $response['choices'][0]['message']['content'];

                        echo '<br><br>';

                        echo nl2br($recommendations);

                    ?>

                </div>

            </div>
            <div class="col-3"></div>
        </div>
    </div>

    <!-- ***** Clients Area Start ***** -->
    

    <!-- ****** Footer Area Start ****** -->
    <footer class="dorne-footer-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 d-md-flex align-items-center justify-content-between">
                    <div class="footer-text">
                    </div>
                    
                </div>
            </div>
        </div>
    </footer>
    <!-- ****** Footer Area End ****** -->

    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap-4 js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/others/plugins.js"></script>
    <!-- Active JS -->
    <script src="js/active.js"></script>

    <?php //debug(); ?>
</body>

</html>