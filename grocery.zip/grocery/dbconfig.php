<?php
session_start();

// Define constants for database credentials
DEFINE("server", "localhost");
DEFINE("user", "root");
DEFINE("password", "");
DEFINE("database", "online_grocery");

// Function to perform INSERT, UPDATE, DELETE queries
function iud($query)
{
    $cid = mysqli_connect(server, user, password, database) or die("Connection error");
    $result = mysqli_query($cid, $query);
    $n = mysqli_affected_rows($cid);
    mysqli_close($cid);
    return $n;
}

// Function to perform SELECT queries
function select($query)
{
    $cid = mysqli_connect(server, user, password, database) or die("Connection error");
    $result = mysqli_query($cid, $query);
    mysqli_close($cid);
    return $result;
}

$db = mysqli_connect(server, user, password, database) or die("Connection error");


function debug() {

    $debug = true;

    if ($debug) {

        echo '<pre>';

        echo '<b>GET:</b><br>';
        foreach($_GET as $key => $value) {
            echo '- ' . $key . ' : ' . htmlspecialchars($value) . '<br>';
        }
        echo '<br>';

        echo '<b>POST:</b><br>';
        foreach($_POST as $key => $value) {
            echo '- ' . $key . ' : ' . htmlspecialchars($value) . '<br>';
        }
        echo '<br>';

        echo '<b>FILES:</b><br>';
        foreach($_FILES as $key => $value) {
            echo '- ' . $key . ' : ' . htmlspecialchars($value) . '<br>';
        }
        echo '<br>';

        echo '<b>SESSION:</b><br>';
        foreach($_SESSION as $key => $value) {
            echo '- ' . $key . ' : ' . htmlspecialchars($value) . '<br>';
        }
        echo '<br>';

    }

}














?>
	