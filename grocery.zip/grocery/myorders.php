<?php
require_once"dbconfig.php";
if(isset($_SESSION['login']) && $_SESSION['login'] != '')
{
	
}
else
{
    ?>
        <script>
            top.window.location='ragister.php';
        </script>

    <?php
    //	header("location:ragister.php");
}

$result=select("SELECT *
FROM cart
INNER JOIN items ON cart.itemid = items.itemid WHERE userid='".$_SESSION['userid']."'");
$result1=select("SELECT sum(price)
FROM cart
INNER JOIN items ON cart.itemid = items.itemid WHERE userid='".$_SESSION['userid']."'");
$result2=select("select * from user where userid='".$_SESSION['userid']."'");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <title>My Cart</title>

    <!-- Core Stylesheet -->
    <link href="style.css" rel="stylesheet">

    <!-- Responsive CSS -->
    <link href="css/responsive/responsive.css" rel="stylesheet">

</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="dorne-load"></div>
    </div>

    <!-- ***** Search Form Area ***** -->
    <div class="dorne-search-form d-flex align-items-center">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="search-close-btn" id="closeBtn">
                        <i class="pe-7s-close-circle" aria-hidden="true"></i>
                    </div>
                    <form action="#" method="get">
                        <input type="search" name="caviarSearch" id="search" placeholder="Search Your Desire Destinations or Events">
                        <input type="submit" class="d-none" value="submit">
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- ***** Header Area Start ***** -->
    <header class="header_area" id="header">
        <div class="container-fluid h-100">
            <div class="row h-100">
                <div class="col-12 h-100">
                    <nav class="h-100 navbar navbar-expand-lg">
					 <a class="navbar-brand" href="index.php">ONLINE GROCERY SHOPPING</a>
                       
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#dorneNav" aria-controls="dorneNav" aria-expanded="false" aria-label="Toggle navigation"><span class="fa fa-bars"></span></button>
                        <!-- Nav -->
                        <div class="collapse navbar-collapse" id="dorneNav">
                            <ul class="navbar-nav mr-auto" id="dorneMenu">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php"> <span class="sr-only">(current)</span></a>
                                </li>
                                 <li class="nav-item">
                                    <a class="nav-link" href="mycart.php"></a>
                                </li>
                                
                                <li class="nav-item">
                                    <a class="nav-link" href="logout.php"></a>
                                </li>
                            </ul>
                            
                           
						       <div class="dorne-signin-btn">
							   <?php
							   if(isset($_SESSION['login']) && $_SESSION['login'] != '')
							   {

                                    include 'usermenu.php';

								   ?>

                                   <!-- 

                                   <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                              
								<a class="nav-link" href="mycart.php">My Cart</a>
								<a class="nav-link" href="category.php">Category</a>
                              
                                	<a class="nav-link" href="logout.php">Logout</a>
								
                                    -->

								   <?php
							   }
								   else
								   {
									   ?>
									   <a href="#">Sign in  or Register</a>
								<a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
								
								   <?php
								   }
							   
							   ?>
                                
                            </div>
                           
                            
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    
    <div class="breadcumb-area bg-img bg-overlay" style="background-image: url(img/bg-img/hero-1.jpg)">
    </div>

	</br>

    <div class="container-fluid">

        <div class="row">
            <div class="col-lg-1 text-center"></div>
            <div class="col-lg-10 text-center">

                <div class="alert alert-light" role="alert">
                    <p style="color:red;font-weight:bold;font-size:20px;">My Order Details</p>
                </div>

            </div>
            <div class="col-lg-1 text-center"></div>

        </div>

    </div>

    <div class="row">
        <div class="col-lg-1"></div>
        <div class="col-lg-10">

            <div class="card text-center">
  
                <div class="card-body" style="text-align: left;">

                    <?php 

                        $sql = 'select * from orders where userid = "' . $_SESSION['userid'] . '" ';
                        $qry = $db->query($sql);
                        
                        if ($qry->num_rows > 0) {

                            while ($order = $qry->fetch_assoc()) {

                                ?>

                                    <h4>Order number: <b><?php echo $order['ordernumber']; ?></b></h4>
                                    
                                    <table>
                                        <tr>
                                            <td><b>Date:</b></td>
                                            <td style="padding-left: 10px !important; vertical-align: top !important;"><?php echo date('d M Y h:i:s a', strtotime($order['orderdate'])); ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><b>Delivery<br>address:</b></td>
                                            <td style="padding-left: 10px; vertical-align: top !important;"><?php echo $order['address']; ?></td>

                                        </tr>
                                        <tr>
                                            <td><b>Delivery status:</b></td>
                                            <td style="padding-left: 10px;"><?php echo $order['orderstatus']; ?></td>
                                        </tr>
                                    </table>


                                    <table class="table table-condensed table-striped">

                                        <thead>
                                            <tr style="background-color: #333; color: #fff;">
                                                <th style="width: 50px;"><b>No.</b></th>
                                                <th><b>Item</b></th>
                                                <th style="width: 150px; text-align: right;"><b>Price (RM)</b></th>
                                            </tr>
                                        </thead>

                                        <tbody>

                                            <?php 

                                                $totalprice = 0;

                                                $sql2 = '

                                                    select * from orderdetails where orderid = "' . $order['orderid'] . '"

                                                ';

                                                $i = 0;

                                                $qry2 = $db->query($sql2);
                                                while ($details = $qry2->fetch_assoc()) {

                                                    $i++;

                                                    $totalprice = $totalprice + $details['price'];

                                                    ?>

                                                        <tr>
                                                            <td><?php echo $i; ?>.</td>
                                                            <td><?php echo $details['title']; ?></td>
                                                            <td style="text-align: right;"><?php echo number_format($details['price'], 2); ?></td>
                                                        </tr>

                                                    <?php

                                                }

                                                ?>

                                                    <tr>
                                                        <td colspan="2" style="text-align: right;"><b>TOTAL:</b></td>
                                                        <td style="text-align: right;"><b><?php echo number_format($totalprice, 2); ?></b></td>
                                                    </tr>

                                                <?php 

                                            ?>

                                        </tbody>

                                    </table>

                                    <br><br>
                                    <hr style="border: 1px solid #000;">
                                    <br><br>


                                <?php 

                            }

                        }

                        else {

                            ?>

                            You have no orders yet.

                            <?php 
                        }

                    ?>


                </div>
	  
            </div>

        </div>
        <div class="col-lg-1"></div>
    </div>


	<footer class="dorne-footer-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 d-md-flex align-items-center justify-content-between">
                    <div class="footer-text">
                    </div>
                    
                </div>
            </div>
        </div>
    </footer>


       

    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap-4 js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/others/plugins.js"></script>
    <!-- Active JS -->
    <script src="js/active.js"></script>
</body>

</html>