<?php require_once"dbconfig.php";
if(isset($_SESSION['login']) && $_SESSION['login'] != '')
{

	
}
else
{
  ?>
  <script>
    top.window.location="login.php";
  </script>
  <?php
  //header("location:login.php");
}

?>
<!DOCTYPE HTML>
<html>
<head>
<?php include"head.php";?> 
<script type="text/javascript" src="js/nicEdit-latest.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
  
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>


  <script type="text/javascript">
  $(document).ready(function () {
$('#dtBasicExample').DataTable();
$('.dataTables_length').addClass('bs-select');
});

  </script>
  <style>
  table.dataTable thead>tr>td.sorting,
table.dataTable thead>tr>td.sorting_asc,
table.dataTable thead>tr>td.sorting_desc,
table.dataTable thead>tr>th.sorting,
table.dataTable thead>tr>th.sorting_asc,
table.dataTable thead>tr>th.sorting_desc {
  padding-right: 30px
}

table.dataTable thead .sorting,
table.dataTable thead .sorting_asc,
table.dataTable thead .sorting_asc_disabled,
table.dataTable thead .sorting_desc,
table.dataTable thead .sorting_desc_disabled {
  cursor: pointer;
  position: relative
}

table.dataTable thead .sorting:after,
table.dataTable thead .sorting:before,
table.dataTable thead .sorting_asc:after,
table.dataTable thead .sorting_asc:before,
table.dataTable thead .sorting_asc_disabled:after,
table.dataTable thead .sorting_asc_disabled:before,
table.dataTable thead .sorting_desc:after,
table.dataTable thead .sorting_desc:before,
table.dataTable thead .sorting_desc_disabled:after,
table.dataTable thead .sorting_desc_disabled:before {
  position: absolute;
  bottom: .9em;
  display: block;
  opacity: .3
}

table.dataTable thead .sorting:before,
table.dataTable thead .sorting_asc:before,
table.dataTable thead .sorting_asc_disabled:before,
table.dataTable thead .sorting_desc:before,
table.dataTable thead .sorting_desc_disabled:before {
  right: 1em;
  content: "\f0de";
  font-family: FontAwesome;
  font-size: 1rem
}

table.dataTable thead .sorting:after,
table.dataTable thead .sorting_asc:after,
table.dataTable thead .sorting_asc_disabled:after,
table.dataTable thead .sorting_desc:after,
table.dataTable thead .sorting_desc_disabled:after {
  content: "\f0dd";
  font-family: FontAwesome;
  right: 16px;
  font-size: 1rem
}

table.dataTable thead .sorting_asc:before,
table.dataTable thead .sorting_desc:after {
  opacity: 1
}

table.dataTable thead .sorting_asc_disabled:before,
table.dataTable thead .sorting_desc_disabled:after {
  opacity: 0
}
  </style>
  </head>
<body>
<div class="page-container">
<div class="left-content">
<div class="inner-content">
<?php //include"header.php";?>
<div class="outter-wp">
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="index.php">Home</a></li>
<li class="active">My Grocery</li>
</ol>
</div>
<div class="graph-visual tables-main">

<div class="graph">
<div class="block-page">
<p>
<h3 class="inner-tittle two">Orders List</h3>

<!--
<a href="additem.php"> <button class="btn btn-pill btn-primary">Add New Items </button></a>
-->
<div class="form-body">

  <!--
<table id="dtBasicExample" class="table table-striped table-bordered" cellspacing="0" width="100%">
  <thead>
    <tr>
	<th class="th-sm">S.no.
      </th>
      <th class="th-sm">Title
      </th>
      <th class="th-sm">Category
      </th>
      <th class="th-sm">Image
      </th>
	  <th class="th-sm" style="width: 80px;">Price
      </th>
       <th class="th-sm">Description
      </th>
	  <th class="th-sm">Actions
      </th>
      
    </tr>
  </thead>
  <tbody>
  <?php 
  $result=select("select * from items");
  $n=1;
  while($r=mysqli_fetch_array($result))
  {  extract($r);
  ?>
    <tr>
      <td><?=$n?></td>
      <td><?=ucwords($Title)?></td>
      <td><?=$category?></td>
       <td><img src="images/<?=$image?>" style="height:40px"></td>
     
	  <td>RM <?php echo number_format($price, 2); ?></td>
      <td><?=ucwords($discription)?></td>
      <td>
         <a href="myphp.php?edit=yes&id=<?=$itemid?>">
          <span class="glyphicon glyphicon-pencil"></span>
        </a>&nbsp;&nbsp;&nbsp;
     <a href="myphp.php?delete=yes&id=<?=$itemid?>" onclick="return confirm('Delete this item, are you sure?');">
          <span class="glyphicon glyphicon-remove"></span>
        </a>
	  
	  
	  </td>
      
    </tr>
    
    <?php
	$n++;
  }
	?>
    
    
    </tbody>

</table>

-->


<?php 

    $sql = 'select * from orders';
    $qry = $db->query($sql);
    
    if ($qry->num_rows > 0) {

        while ($order = $qry->fetch_assoc()) {

            ?>

                <h4>Order number: <b><?php echo $order['ordernumber']; ?></b></h4>
                
                <table>
                    <tr>
                        <td><b>Date:</b></td>
                        <td style="padding-left: 10px !important; vertical-align: top !important;"><?php echo date('d M Y h:i:s a', strtotime($order['orderdate'])); ?>
                        </td>
                    </tr>
                    <tr>
                        <td><b>Delivery<br>address:</b></td>
                        <td style="padding-left: 10px; vertical-align: top !important;"><?php echo $order['address']; ?></td>

                    </tr>
                    <tr>
                        <td><b>Delivery status:</b></td>
                        <td style="padding-left: 10px;"><?php echo $order['orderstatus']; ?></td>
                    </tr>
                </table>


                <table class="table table-condensed table-striped">

                    <thead>
                        <tr style="background-color: #333; color: #fff;">
                            <th style="width: 50px;"><b>No.</b></th>
                            <th><b>Item</b></th>
                            <th style="width: 150px; text-align: right;"><b>Price (RM)</b></th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php 

                            $totalprice = 0;

                            $sql2 = '

                                select * from orderdetails where orderid = "' . $order['orderid'] . '"

                            ';

                            $i = 0;

                            $qry2 = $db->query($sql2);
                            while ($details = $qry2->fetch_assoc()) {

                                $i++;

                                $totalprice = $totalprice + $details['price'];

                                ?>

                                    <tr>
                                        <td><?php echo $i; ?>.</td>
                                        <td><?php echo $details['title']; ?></td>
                                        <td style="text-align: right;"><?php echo number_format($details['price'], 2); ?></td>
                                    </tr>

                                <?php

                            }

                            ?>

                                <tr>
                                    <td colspan="2" style="text-align: right;"><b>TOTAL:</b></td>
                                    <td style="text-align: right;"><b><?php echo number_format($totalprice, 2); ?></b></td>
                                </tr>

                            <?php 

                        ?>

                    </tbody>

                </table>

                <br><br>
                <hr style="border: 1px solid #000;">
                <br><br>


            <?php 

        }

    }

    else {

        ?>

        You have no orders yet.

        <?php 
    }

?>

</div>


</p>
</div>

</div>

</div>
</div>
<?php include"footer.php";?>

</div>
</div>
<?php include"side_bar.php";?>
</div>
<?php include"footer_script.php";?>

</body>
</html>