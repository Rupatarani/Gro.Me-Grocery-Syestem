<div class="header">
		<div class="container">
			<div class="row">
			  <div class="col-md-12">
				 <div class="header-left">
					 
					 <div class="menu">
						  <a class="toggleMenu" href="#"><img src="images/nav.png" alt="" /></a>
						    <ul class="nav" id="nav">
						    	
						    	<li><a href="index.php">Home</a></li>
						    	<li><a href="signin.php">Signin</a></li>
						    	<li><a href="login.php">Login</a></li>
						    	<li><a href="change_password.php">Change Password</a></li>
						        <li><a href="reset_password.php">Reset Password</a></li>
						    	<li><a href="about.php">About</a></li>
						    	<li><a href="logout.php">logout</a></li>
						        <li><a href="contact.php">Contact</a></li>								
								<div class="clear"></div>
							</ul>
							<script type="text/javascript" src="js/responsive-nav.js"></script>
				    </div>							
	    		    <div class="clear"></div>
	    	    </div>
	             
	      </div>
		 </div>
	    </div>
	</div>