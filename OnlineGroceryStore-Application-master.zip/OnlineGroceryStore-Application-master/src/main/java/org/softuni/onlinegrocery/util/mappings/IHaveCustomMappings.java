package org.softuni.onlinegrocery.util.mappings;

import org.modelmapper.ModelMapper;

public interface IHaveCustomMappings {
    void configureMappings(ModelMapper mapper);
}
