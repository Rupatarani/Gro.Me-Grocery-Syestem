package org.softuni.onlinegrocery.domain.entities.enumeration;

public enum Status {
    
    Pending, Shipped, Delivered, Acquired;
}
