package org.softuni.onlinegrocery.service;

import org.junit.Test;

import static org.junit.Assert.*;

public class OrderServiceImplTests {

    @Test
    public void createOrder() {
    }

    @Test
    public void findAllOrders() {
    }

    @Test
    public void findOrdersByCustomer() {
    }

    @Test
    public void findOrderById() {
    }

    @Test
    public void findOrdersByStatus() {
    }

    @Test
    public void changeOrderStatus() {
    }

    @Test
    public void findOrdersByCustomerAndStatus() {
    }
}