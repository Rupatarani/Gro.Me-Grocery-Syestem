package org.softuni.onlinegrocery.service;

import org.junit.Test;

import static org.junit.Assert.*;

public class CategoryServiceImplTests {

    @Test
    public void addCategory() {
    }

    @Test
    public void findAllCategories() {
    }

    @Test
    public void findCategoryById() {
    }

    @Test
    public void editCategory() {
    }

    @Test
    public void deleteCategory() {
    }

    @Test
    public void findAllFilteredCategories() {
    }
}