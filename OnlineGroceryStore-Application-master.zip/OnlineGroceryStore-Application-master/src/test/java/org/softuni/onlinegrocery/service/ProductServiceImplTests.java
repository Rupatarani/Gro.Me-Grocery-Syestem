package org.softuni.onlinegrocery.service;

import org.junit.Test;

import static org.junit.Assert.*;

public class ProductServiceImplTests {

    @Test
    public void createProduct() {
    }

    @Test
    public void findAllProducts() {
    }

    @Test
    public void findProductById() {
    }

    @Test
    public void editProduct() {
    }

    @Test
    public void deleteProduct() {
    }

    @Test
    public void findAllByCategory() {
    }

    @Test
    public void findAllFilteredProducts() {
    }

    @Test
    public void findAllByCategoryFilteredProducts() {
    }

    @Test
    public void findProductsByPartOfName() {
    }
}